$(document).ready(function(){
    $('.fa-regular').click(function(){
      $('.modal-box').toggleClass("show-modal");
      $('.fa-regular').toggleClass("show-modal");
    });
    $('.fa-times').click(function(){
      $('.modal-box').toggleClass("show-modal");
      $('.fa-regular').toggleClass("show-modal");
    });
    $('.closeForm').click(function(){
      $('.modal-box').toggleClass("show-modal");
      $('.fa-regular').toggleClass("show-modal");
    });
  
  });



  





  